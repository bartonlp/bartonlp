-- MySQL dump 10.13  Distrib 8.0.31, for Linux (x86_64)
--
-- Host: localhost    Database: bartonphillips
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `finger` varchar(50) NOT NULL,
  `count` int DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  PRIMARY KEY (`email`,`finger`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES ('Barton Phillips','bartonphillips@gmail.com','A6Ly1ixt3HDYQXQqNGoj',1,'2022-12-07 16:23:08','2022-12-07 16:23:08'),('Barton Phillips','bartonphillips@gmail.com','agvmgLtbOej09pGw27ZF',20,'2022-07-02 17:55:50','2022-11-25 07:48:42'),('Barton Phillips','bartonphillips@gmail.com','aZxrc212BRsQLrMgyMZF',8,'2022-06-30 07:44:46','2022-09-06 17:50:25'),('Barton Phillips','Bartonphillips@gmail.com','Dg1XcKaxFwsCF7YiFQEz',2,'2022-06-25 08:13:00','2022-06-25 12:29:53'),('Barton Phillips','bartonphillips@gmail.com','e30hJHxUeaToTAB6g4Zv',3,'2022-06-15 12:51:57','2022-06-15 14:19:28'),('Barton Phillips','bartonphillips@gmail.com','FPc5lLUsrf46OK6mkste',3,'2022-06-15 14:24:27','2022-07-19 13:38:27'),('Barton Phillips','bartonphillips@gmail.com','gKjwDG88VqcilIMlQ2Kj',1,'2022-06-15 14:58:22','2022-06-15 14:58:22'),('Barton Phillips','bartonphillips@gmail.com','hFBzuVRDeIWdbhXmhZv7',353,'2022-06-12 07:49:02','2022-12-17 15:15:19'),('Barton Phillips','bartonphillips@gmail.com','HrhBcA7j0gi4Pzp7ndjp',1,'2022-09-11 15:39:34','2022-09-11 15:39:34'),('Barton Phillips','bartonphillips@gmail.com','J4C3rOAXmbicnj3XFlGB',1,'2022-12-08 09:07:04','2022-12-08 09:07:04'),('Barton Phillips','bartonphillips@gmail.com','MUlwB32Q4u0w3HgkWKRP',1,'2022-12-07 20:13:03','2022-12-07 20:13:03'),('Barton Phillips','bartonphillips@gmail.com','mUQurQMLPE4rk0mjhamh',3,'2022-10-27 20:52:38','2022-12-14 06:31:59'),('Barton Phillips','bartonphillips@gmail.com','rugSf95WurLb9ZTC6yNt',1,'2022-11-12 15:49:20','2022-11-12 15:49:20'),('Barton Phillips','bartonphillips@gmail.com','Sf0RS3RfRhY8vke1a5uN',2,'2022-11-18 13:06:13','2022-11-18 13:06:23'),('Barton Phillips','bartonphillips@gmail.com','Z1Kx9vql4QxiMB9brOd2',179,'2022-06-14 13:42:11','2022-12-15 13:24:55'),('Barton Phillips ','bartonphillips@gmail.com ','ziYHr1kB21AWEpK03R8H',3,'2022-06-15 14:33:36','2022-06-15 14:36:51'),('Bonnie Burch','bonnieburch2015@gmail.com','AP8Pbm3GSxShU92ozThM',1,'2022-06-15 08:34:32','2022-06-15 08:34:32'),('Bonnie Burch','bonnieburch2015@gmail.com','hFBzuVRDeIWdbhXmhZv7',4,'2022-06-14 16:58:58','2022-11-18 12:53:02'),('Bonnie Burch','bonnieburch2015@gmail.com','Sf0RS3RfRhY8vke1a5uN',4,'2022-11-18 12:48:04','2022-11-18 12:55:02');
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mutuals`
--

DROP TABLE IF EXISTS `mutuals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mutuals` (
  `date` date NOT NULL,
  `stock` varchar(100) NOT NULL,
  `price` varchar(30) DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  PRIMARY KEY (`date`,`stock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mutuals`
--

LOCK TABLES `mutuals` WRITE;
/*!40000 ALTER TABLE `mutuals` DISABLE KEYS */;
INSERT INTO `mutuals` VALUES ('2022-09-02','AEPGX','47.4400',1076,'2022-09-06 13:34:50','2022-09-06 20:00:02'),('2022-09-02','CAIBX','62.0900',3002,'2022-09-06 13:34:50','2022-09-06 20:00:03'),('2022-09-02','SMCWX','56.0300',348,'2022-09-06 13:34:50','2022-09-07 20:00:03'),('2022-09-06','CAIBX','61.8300',3824,'2022-09-07 20:00:02','2022-09-07 20:00:02'),('2022-09-06','SMCWX','55.7000',348,'2022-09-08 20:00:03','2022-09-08 20:00:03'),('2022-09-07','CAIBX','62.4100',3824,'2022-09-08 20:00:03','2022-09-09 20:00:01'),('2022-09-07','SMCWX','56.6000',348,'2022-09-09 20:00:02','2022-09-09 20:00:02'),('2022-09-08','CAIBX','62.5900',3824,'2022-09-12 20:00:01','2022-09-12 20:00:01'),('2022-09-09','CAIBX','63.2800',3824,'2022-09-13 20:00:26','2022-09-13 20:00:26'),('2022-09-09','SMCWX','58.1700',348,'2022-09-12 20:00:03','2022-09-13 20:00:35'),('2022-09-12','SMCWX','58.8600',348,'2022-09-14 20:00:04','2022-09-14 20:00:04'),('2022-09-13','CAIBX','61.8200',3824,'2022-09-14 20:00:03','2022-09-14 20:00:03'),('2022-09-13','SMCWX','56.7900',348,'2022-09-15 20:00:06','2022-09-15 20:00:06'),('2022-09-14','CAIBX','61.9000',3824,'2022-09-15 20:00:03','2022-09-16 20:00:03'),('2022-09-15','SMCWX','56.5700',348,'2022-09-16 20:00:04','2022-09-19 20:00:04'),('2022-09-16','CAIBX','61.3900',3824,'2022-09-19 20:00:03','2022-09-19 20:00:03'),('2022-09-16','SMCWX','55.7800',348,'2022-09-20 20:00:04','2022-09-20 20:00:04'),('2022-09-19','CAIBX','61.5400',3824,'2022-09-20 20:00:03','2022-09-21 20:00:01'),('2022-09-19','SMCWX','56.0000',348,'2022-09-21 20:00:02','2022-09-21 20:00:02'),('2022-09-21','CAIBX','60.4300',3824,'2022-09-22 20:00:02','2022-09-22 20:00:02'),('2022-09-21','SMCWX','54.5700',348,'2022-09-22 20:00:03','2022-09-22 20:00:03'),('2022-09-22','CAIBX','60.1000',3824,'2022-09-23 20:00:02','2022-09-23 20:00:02'),('2022-09-22','SMCWX','53.5900',348,'2022-09-23 20:00:04','2022-09-23 20:00:04'),('2022-09-23','CAIBX','58.9100',3824,'2022-09-26 20:00:02','2022-09-26 20:00:02'),('2022-09-23','SMCWX','52.4400',348,'2022-09-26 20:00:05','2022-09-26 20:00:05'),('2022-09-26','CAIBX','58.0500',3824,'2022-09-27 20:00:02','2022-09-27 20:00:02'),('2022-09-26','SMCWX','51.8000',348,'2022-09-27 20:00:03','2022-09-27 20:00:03'),('2022-09-27','CAIBX','57.7700',3824,'2022-09-28 20:00:03','2022-09-28 20:00:03'),('2022-09-27','SMCWX','51.9400',348,'2022-09-28 20:00:04','2022-09-28 20:00:04'),('2022-09-28','CAIBX','58.6000',3824,'2022-09-29 20:00:03','2022-09-29 20:00:03'),('2022-09-28','SMCWX','53.0400',348,'2022-09-29 20:00:05','2022-09-29 20:00:05'),('2022-09-29','CAIBX','57.8600',3824,'2022-09-30 20:00:04','2022-09-30 20:00:04'),('2022-09-29','SMCWX','52.0400',348,'2022-09-30 20:00:06','2022-09-30 20:00:06'),('2022-09-30','CAIBX','57.4100',3824,'2022-10-03 20:00:04','2022-10-03 20:00:04'),('2022-09-30','SMCWX','51.9900',348,'2022-10-03 20:00:06','2022-10-03 20:00:06'),('2022-10-03','CAIBX','58.5600',3824,'2022-10-04 20:00:02','2022-10-04 20:00:02'),('2022-10-03','SMCWX','53.1700',348,'2022-10-04 20:00:04','2022-10-04 20:00:04'),('2022-10-04','CAIBX','59.8500',3824,'2022-10-05 20:00:03','2022-10-05 20:00:03'),('2022-10-04','SMCWX','55.1100',348,'2022-10-05 20:00:04','2022-10-05 20:00:04'),('2022-10-05','CAIBX','59.5900',3824,'2022-10-06 20:00:02','2022-10-06 20:00:02'),('2022-10-05','SMCWX','54.8000',348,'2022-10-06 20:00:03','2022-10-06 20:00:03'),('2022-10-06','CAIBX','58.7500',3824,'2022-10-07 20:00:03','2022-10-07 20:00:03'),('2022-10-06','SMCWX','54.4600',348,'2022-10-07 20:00:04','2022-10-07 20:00:04'),('2022-10-07','CAIBX','58.0400',3824,'2022-10-10 20:00:04','2022-10-10 20:00:04'),('2022-10-07','SMCWX','53.1100',348,'2022-10-10 20:00:06','2022-10-10 20:00:06'),('2022-10-10','CAIBX','57.7100',3824,'2022-10-11 20:00:07','2022-10-11 20:00:07'),('2022-10-10','SMCWX','52.6100',348,'2022-10-11 20:00:10','2022-10-11 20:00:10'),('2022-10-11','CAIBX','57.5000',3824,'2022-10-12 20:00:03','2022-10-12 20:00:03'),('2022-10-11','SMCWX','52.2000',348,'2022-10-12 20:00:05','2022-10-12 20:00:05'),('2022-10-12','SMCWX','52.0400',348,'2022-10-13 20:00:03','2022-10-13 20:00:03'),('2022-10-13','SMCWX','52.7500',348,'2022-10-14 20:00:04','2022-10-14 20:00:04'),('2022-10-14','CAIBX','57.4300',3849,'2022-10-17 20:00:03','2022-10-17 20:00:03'),('2022-10-14','SMCWX','51.5900',348,'2022-10-17 20:00:06','2022-10-18 20:00:07'),('2022-10-17','CAIBX','58.3000',3849,'2022-10-18 20:00:05','2022-10-18 20:00:05'),('2022-10-18','CAIBX','58.7100',3849,'2022-10-19 20:00:03','2022-10-19 20:00:03'),('2022-10-18','SMCWX','53.6500',348,'2022-10-19 20:00:05','2022-10-19 20:00:05'),('2022-10-19','CAIBX','58.2800',3849,'2022-10-20 20:00:04','2022-10-20 20:00:04'),('2022-10-19','SMCWX','52.6300',348,'2022-10-20 20:00:06','2022-10-20 20:00:06'),('2022-10-20','CAIBX','57.8800',3849,'2022-10-21 20:00:05','2022-10-24 20:00:02'),('2022-10-20','SMCWX','52.2300',348,'2022-10-21 20:00:06','2022-10-21 20:00:06'),('2022-10-21','CAIBX','58.6700',3849,'2022-10-25 20:00:03','2022-10-25 20:00:03'),('2022-10-21','SMCWX','53.0400',348,'2022-10-24 20:00:05','2022-10-24 20:00:05'),('2022-10-24','CAIBX','58.9400',3849,'2022-10-26 20:00:03','2022-10-26 20:00:03'),('2022-10-24','SMCWX','53.0800',348,'2022-10-25 20:00:05','2022-10-25 20:00:05'),('2022-10-25','SMCWX','54.3200',348,'2022-10-26 20:00:05','2022-10-26 20:00:05'),('2022-10-26','CAIBX','59.9000',3849,'2022-10-27 20:00:02','2022-10-27 20:00:02'),('2022-10-26','SMCWX','54.7300',348,'2022-10-27 20:00:03','2022-10-27 20:00:03'),('2022-10-27','CAIBX','60.0100',3849,'2022-10-28 20:00:02','2022-10-31 20:00:05'),('2022-10-27','SMCWX','54.4500',348,'2022-10-28 20:00:04','2022-10-28 20:00:04'),('2022-10-28','CAIBX','60.7300',3849,'2022-11-01 20:00:01','2022-11-01 20:00:01'),('2022-10-28','SMCWX','55.1700',348,'2022-10-31 20:00:06','2022-10-31 20:00:06'),('2022-10-31','CAIBX','60.4700',3849,'2022-11-02 20:00:03','2022-11-02 20:00:03'),('2022-10-31','SMCWX','54.9000',348,'2022-11-01 20:00:03','2022-11-01 20:00:03'),('2022-11-01','CAIBX','60.7000',3849,'2022-11-03 20:00:03','2022-11-03 20:00:03'),('2022-11-01','SMCWX','55.2300',348,'2022-11-02 20:00:05','2022-11-02 20:00:05'),('2022-11-02','CAIBX','59.9900',3849,'2022-11-04 20:00:02','2022-11-04 20:00:02'),('2022-11-02','SMCWX','54.1500',348,'2022-11-03 20:00:05','2022-11-03 20:00:05'),('2022-11-03','SMCWX','53.7700',348,'2022-11-04 20:00:02','2022-11-04 20:00:02'),('2022-11-17','CAIBX','62.8800',3849,'2022-11-19 15:17:45','2022-11-21 20:00:03'),('2022-11-17','SMCWX','56.9600',348,'2022-11-19 15:17:45','2022-11-21 20:00:04'),('2022-11-18','SMCWX','57.0500',348,'2022-11-22 20:00:03','2022-11-22 20:00:03'),('2022-11-21','CAIBX','63.1600',3849,'2022-11-22 20:00:02','2022-11-22 20:00:02'),('2022-11-21','SMCWX','56.6200',348,'2022-11-23 20:00:06','2022-11-23 20:00:06'),('2022-11-22','CAIBX','63.7600',3849,'2022-11-23 20:00:04','2022-11-23 20:00:04'),('2022-11-22','SMCWX','57.1200',348,'2022-11-24 20:00:04','2022-11-24 20:00:04'),('2022-11-23','CAIBX','64.0300',3849,'2022-11-24 20:00:02','2022-11-25 20:00:02'),('2022-11-23','SMCWX','57.5500',348,'2022-11-25 20:00:03','2022-11-28 20:00:04'),('2022-11-25','CAIBX','64.2100',3849,'2022-11-28 20:00:02','2022-11-28 20:00:02'),('2022-11-25','SMCWX','57.7500',348,'2022-11-29 20:00:10','2022-11-29 20:00:10'),('2022-11-28','CAIBX','63.5600',3849,'2022-11-29 20:00:05','2022-11-29 20:00:05'),('2022-11-28','SMCWX','56.9400',348,'2022-11-30 20:00:10','2022-11-30 20:00:10'),('2022-11-29','CAIBX','63.7300',3849,'2022-11-30 20:00:03','2022-11-30 20:00:03'),('2022-11-29','SMCWX','57.0100',348,'2022-12-01 20:00:03','2022-12-01 20:00:03'),('2022-11-30','CAIBX','64.8600',3849,'2022-12-01 20:00:02','2022-12-01 20:00:02'),('2022-11-30','SMCWX','58.5700',348,'2022-12-02 20:00:03','2022-12-02 20:00:03'),('2022-12-01','CAIBX','65.1200',3849,'2022-12-02 20:00:02','2022-12-02 20:00:02'),('2022-12-01','SMCWX','58.9900',348,'2022-12-05 20:00:05','2022-12-05 20:00:05'),('2022-12-02','CAIBX','65.1500',3849,'2022-12-05 20:00:02','2022-12-05 20:00:02'),('2022-12-02','SMCWX','59.1400',348,'2022-12-06 20:00:06','2022-12-06 20:00:06'),('2022-12-05','CAIBX','64.4800',3849,'2022-12-06 20:00:02','2022-12-06 20:00:02'),('2022-12-05','SMCWX','57.9500',348,'2022-12-07 20:00:06','2022-12-07 20:00:06'),('2022-12-06','CAIBX','64.1600',3849,'2022-12-07 20:00:03','2022-12-07 20:00:03'),('2022-12-06','SMCWX','57.1400',348,'2022-12-08 20:00:06','2022-12-08 20:00:06'),('2022-12-07','CAIBX','64.1800',3849,'2022-12-08 20:00:03','2022-12-08 20:00:03'),('2022-12-07','SMCWX','57.1800',348,'2022-12-09 20:00:02','2022-12-09 20:00:02'),('2022-12-08','CAIBX','64.3900',3849,'2022-12-09 20:00:01','2022-12-09 20:00:01'),('2022-12-08','SMCWX','57.6500',348,'2022-12-12 20:00:07','2022-12-12 20:00:07'),('2022-12-09','CAIBX','64.2700',3849,'2022-12-12 20:00:02','2022-12-12 20:00:02'),('2022-12-09','SMCWX','57.4300',348,'2022-12-13 20:00:04','2022-12-13 20:00:04'),('2022-12-12','CAIBX','64.6400',3849,'2022-12-13 20:00:03','2022-12-13 20:00:03'),('2022-12-12','SMCWX','57.9000',348,'2022-12-14 20:00:08','2022-12-14 20:00:08'),('2022-12-13','CAIBX','65.0400',3849,'2022-12-14 20:00:02','2022-12-14 20:00:02'),('2022-12-13','SMCWX','58.4700',348,'2022-12-15 20:00:10','2022-12-15 20:00:10'),('2022-12-14','CAIBX','64.9800',3849,'2022-12-15 20:00:04','2022-12-15 20:00:04'),('2022-12-14','SMCWX','58.4400',348,'2022-12-16 20:00:03','2022-12-16 20:00:03'),('2022-12-15','CAIBX','64.1200',3849,'2022-12-16 20:00:02','2022-12-16 20:00:02');
/*!40000 ALTER TABLE `mutuals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stocks`
--

DROP TABLE IF EXISTS `stocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stocks` (
  `stock` varchar(10) NOT NULL,
  `price` decimal(8,2) DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `lasttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` enum('active','watch','sold','mutual','IRA') DEFAULT NULL,
  PRIMARY KEY (`stock`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stocks`
--

LOCK TABLES `stocks` WRITE;
/*!40000 ALTER TABLE `stocks` DISABLE KEYS */;
INSERT INTO `stocks` VALUES ('ABBV',24.88,100,'ABBVIE INC','2018-03-28 14:38:37','active'),('AEPGX',47.22,1076,'AMER FDS EUROPACIFIC A','2022-09-07 12:34:03','sold'),('ANGL',23.00,100,'Fallen Angel High Yield Bond ETF','2020-10-21 18:38:20','watch'),('BA',235.66,100,'Boeing ','2021-06-15 20:01:27','sold'),('BAC',39.30,100,'Bank Of America','2022-04-18 17:41:08','watch'),('BMWYY',20.96,100,'BAYERISCHE MOTOREN WERKE','2020-06-02 14:54:14','active'),('BP',34.68,1200,'BP PLC SPONS ADR','2020-05-14 17:22:29','active'),('BRW',11.94,875,'SABA CAPITAL INCOME & OPPORTUNITIES FD','2022-10-13 20:21:42','active'),('BST',31.23,400,'BLACKROCK SCIENCE & TECH','2022-10-13 20:23:49','active'),('BUD',73.00,100,'ANHEUSER BUSCH INBEV','2018-11-13 14:37:49','sold'),('CAIBX',56.45,3849,'CAPITAL INCOME BLDR CL A','2022-10-17 00:22:51','mutual'),('CII',13.35,2000,'Blackrock Enhanced Capital','2022-10-13 20:28:09','active'),('CSCO',36.75,100,'Cisco Systems','2020-03-30 16:41:43','active'),('CTVA',52.60,183,'Cortiva Inc (dow)','2022-06-25 01:04:05','sold'),('CVX',60.18,200,'CHEVRON CORPORATION','2018-01-03 19:05:56','active'),('DB',18.10,200,'DEUTSCHE BANK AG','2018-02-21 23:20:05','sold'),('DD',58.33,183,'DUPONT DE NEMOURS','2022-10-13 18:45:03','sold'),('DEO',135.00,100,'Diageo','2020-10-21 17:59:29','watch'),('DIAX',15.35,500,'Nuveen DOW 30 Dynamic','2022-05-26 00:11:38','active'),('DIS',126.00,100,'Disney','2020-10-21 18:00:27','watch'),('DOW',39.95,366,'Dow','2022-10-13 20:41:23','active'),('DTRUY',15.00,300,'DAIMLER TRUCK ADR','2022-05-20 15:11:44','sold'),('DWDP',24.75,550,'DOWDUPONT INC','2019-06-07 14:37:35','sold'),('ENB',36.96,200,'Enbridge Inc.','2022-10-13 20:42:15','active'),('F',9.64,1000,'Ford','2022-10-13 20:43:14','active'),('FRNRX',20.54,820,'FRANKLIN STRAT NAT RES A','2021-06-15 20:02:42','sold'),('GE',22.33,0,'GE','2018-02-21 23:26:20','sold'),('HPT',5.88,1000,'HOSPITALITY PROPERTIES','2021-11-02 19:55:36','sold'),('HYG',80.27,100,'Ishairs High Yield','2022-04-18 18:01:41','watch'),('IBM',91.28,100,'INTERNATIONAL BUSINESS','2022-10-13 20:44:00','active'),('ISRG',277.46,100,'Intuitive Surgical  ','2022-04-18 17:59:37','watch'),('JPM',80.00,100,'J.P Morgan','2020-04-17 20:42:25','watch'),('KD',13.85,20,'Kyndryl Holdings Inc.','2022-05-20 15:12:18','sold'),('KR',27.98,300,'Kroger','2022-10-13 20:10:51','active'),('LMT',468.87,100,'Lockhead','2022-04-18 17:58:46','watch'),('MBGAF',26.64,300,'Mercedes-Benz Group AG','2022-10-13 20:38:02','active'),('NLY',36.56,937,'ANNALY CAPITAL MANAGEMNT','2022-10-13 18:55:07','active'),('NNN',46.74,100,'National Retail Properties Inc.','2022-04-28 14:46:19','watch'),('NOC',467.42,100,'Northrup','2022-04-18 17:57:08','watch'),('PCG',44.95,200,'PG&E CORPORATION','2018-02-21 23:18:18','sold'),('PFE',17.29,400,'PFIZER INCORPORATED','2022-10-13 20:40:00','active'),('PM',90.67,300,'PHILIP MORRIS','2022-10-13 20:45:54','active'),('PRU',44.50,396,'PRUDENTIAL FINANCIAL INC','2022-10-13 20:06:28','active'),('RDIV',38.35,500,'Investco Etf','2022-10-13 20:47:12','active'),('RTX',105.03,100,'Raytheon','2022-04-18 17:55:25','watch'),('SHEL',51.27,1200,'Shell PLC ADR','2022-03-07 17:05:20','active'),('SMCWX',38.25,348,'AMER FDS SMALLCAP WLD ','2022-04-15 01:40:14','mutual'),('SNH',8.05,1000,'SENIOR HOUSING PROP TR','2019-06-07 14:29:56','sold'),('SVC',6.08,700,'Service PPTYS TR','2020-08-21 17:22:14','sold'),('SYY',35.70,300,'SYSCO CORPORATION','2018-01-03 19:05:56','active'),('T',26.56,1300,'AT&T INC','2022-10-13 20:15:31','active'),('TFC',35.76,100,'Truist Financial Corp ','2022-10-13 20:49:39','active'),('TGT',97.89,300,'Target','2022-10-13 20:18:17','active'),('VLKAF',223.51,100,'Volkswagen AG','2022-04-18 18:15:32','watch'),('VTRS',8.59,49,'VIATRIS INC','2022-07-16 12:17:36','sold'),('VZ',50.97,400,'VERIZON COMMUNICATIONS','2018-03-22 19:12:51','active'),('WBA',44.54,100,'Walgreens','2022-04-18 17:42:00','watch'),('WBD',17.15,314,'Warner Bros.','2022-05-20 15:30:47','sold'),('WES',20.77,758,'Western Gas Partners','2020-03-30 16:56:21','active'),('WFC',29.20,200,'WELLS FARGO & CO NEW','2022-10-13 20:51:44','active'),('WMT',94.59,100,'WalMart','2022-10-13 20:52:23','active'),('WTRG',15.06,666,'ESSENTIAL UTILS INC','2020-03-30 16:59:01','active'),('XEL',24.08,200,'XCEL ENERGY INC','2018-01-03 19:05:56','active'),('XOM',57.40,200,'EXXON MOBIL CORP','2022-10-13 20:53:28','active');
/*!40000 ALTER TABLE `stocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stocktotals`
--

DROP TABLE IF EXISTS `stocktotals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stocktotals` (
  `total` varchar(50) NOT NULL,
  `dji` varchar(30) DEFAULT NULL,
  `created` date NOT NULL,
  PRIMARY KEY (`total`,`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stocktotals`
--

LOCK TABLES `stocktotals` WRITE;
/*!40000 ALTER TABLE `stocktotals` DISABLE KEYS */;
INSERT INTO `stocktotals` VALUES ('842,224.74','29,590.41','2022-09-23'),('842,325.73',NULL,'2022-06-20'),('845,548.99','29,634.83','2022-10-14'),('847,831.25',NULL,'2022-06-17'),('852,640.64',NULL,'2022-06-22'),('854,299.45','30,185.82','2022-10-17'),('855,170.80',NULL,'2022-06-16'),('856,923.34',NULL,'2022-06-23'),('857,452.67','30,038.72','2022-10-13'),('859,245.80',NULL,'2022-06-21'),('860,092.01','30,523.80','2022-10-18'),('863,408.06',NULL,'2022-07-14'),('863,820.86','30,423.81','2022-10-19'),('863,879.63','30,333.59','2022-10-20'),('865,161.69','28,725.51','2022-09-30'),('866,396.26','30,076.68','2022-09-22'),('870,222.42','29,210.85','2022-10-12'),('870,254.89','29,202.88','2022-10-10'),('870,518.65','29,225.61','2022-09-29'),('871,636.17',NULL,'2022-06-24'),('871,654.60',NULL,'2022-07-13'),('871,855.18',NULL,'2022-07-15'),('872,563.11',NULL,'2022-07-18'),('873,169.79','30,183.78','2022-09-21'),('873,193.53','29,239.19','2022-10-11'),('875,209.93','31,082.56','2022-10-21'),('875,422.49',NULL,'2022-06-15'),('876,831.26',NULL,'2022-07-12'),('876,926.48','29,134.99','2022-09-27'),('877,232.13',NULL,'2022-07-06'),('880,154.28','30,706.23','2022-09-20'),('880,216.64','31,499.62','2022-10-24'),('881,410.65','29,490.89','2022-10-03'),('881,937.40',NULL,'2022-07-05'),('881,961.11',NULL,'2022-07-08'),('882,015.69',NULL,'2022-07-11'),('882,428.91','29,296.79','2022-10-07'),('883,794.31',NULL,'2022-06-14'),('884,431.00',NULL,'2022-07-07'),('886,338.01','29,260.81','2022-09-26'),('886,458.19','30,822.42','2022-09-16'),('887,040.08','29,683.74','2022-09-28'),('887,060.39',NULL,'2022-07-19'),('887,328.69',NULL,'2022-07-22'),('887,374.76',NULL,'2022-06-30'),('887,608.73','31,019.68','2022-09-19'),('888,027.03',NULL,'2022-07-20'),('888,263.60',NULL,'2022-02-24'),('890,463.79',NULL,'2022-07-21'),('890,904.60',NULL,'2022-07-26'),('890,976.68','30,961.82','2022-09-15'),('891,141.63',NULL,'2022-06-27'),('891,380.56',NULL,'2022-07-04'),('891,710.70','31,836.74','2022-10-25'),('892,829.22',NULL,'2022-07-01'),('892,896.95',NULL,'2022-06-29'),('893,686.28','29,926.94','2022-10-06'),('894,128.87','31,145.30','2022-09-06'),('895,362.80',NULL,'2022-06-13'),('895,676.54',NULL,'2022-06-28'),('895,708.07',NULL,'2022-02-23'),('896,193.89',NULL,'2022-07-25'),('897,629.52','31,839.11','2022-10-26'),('898,155.28','31,318.44','2022-09-05'),('899,321.14',NULL,'2022-03-01'),('899,625.18','31,318.44','2022-09-02'),('900,159.16','31,581.28','2022-09-07'),('900,178.77','30,273.87','2022-10-05'),('900,435.07',NULL,'2022-07-27'),('901,651.40','30,316.32','2022-10-04'),('901,849.94',NULL,'2022-05-20'),('901,909.21',NULL,'2022-02-25'),('902,072.17','31,774.52','2022-09-08'),('902,338.32','31,656.42','2022-09-01'),('903,521.66','31,104.97','2022-09-13'),('904,258.11',NULL,'2022-02-22'),('904,460.73',NULL,'2022-08-31'),('904,833.38',NULL,'2022-02-28'),('905,026.67','31,135.09','2022-09-14'),('905,437.72',NULL,'2022-03-04'),('906,316.47',NULL,'2022-07-28'),('906,327.58','32,033.28','2022-10-27'),('906,488.95','32,513.94','2022-11-09'),('907,116.43','32,001.25','2022-11-03'),('908,416.04','32,147.76','2022-11-02'),('908,591.28',NULL,'2022-03-02'),('910,035.72',NULL,'2022-08-04'),('910,772.69',NULL,'2022-03-03'),('911,523.60',NULL,'2022-08-30'),('911,657.48',NULL,'2022-05-23'),('912,095.53',NULL,'2022-02-21'),('912,313.35','32,403.22','2022-11-04'),('913,568.40',NULL,'2022-02-18'),('914,067.58','32,151.71','2022-09-09'),('914,073.90',NULL,'2022-08-05'),('914,849.73',NULL,'2022-05-24'),('915,291.52',NULL,'2022-05-12'),('915,310.22','32,732.95','2022-10-31'),('915,675.97','32,827.00','2022-11-07'),('915,873.22',NULL,'2022-05-11'),('916,421.27',NULL,'2022-05-19'),('917,095.55','32,861.80','2022-10-28'),('917,158.76',NULL,'2022-08-08'),('917,783.26',NULL,'2022-02-14'),('917,809.23',NULL,'2022-08-09'),('918,769.50',NULL,'2022-05-18'),('918,911.70',NULL,'2022-08-02'),('919,033.08',NULL,'2022-02-15'),('919,064.79',NULL,'2022-02-17'),('919,259.37','32,653.20','2022-11-01'),('919,986.31','32,381.34','2022-09-12'),('920,728.55',NULL,'2022-08-03'),('920,776.72',NULL,'2022-07-29'),('921,048.45',NULL,'2022-05-10'),('921,626.34',NULL,'2022-08-01'),('921,978.73','33,160.83','2022-11-08'),('922,000.57',NULL,'2022-08-26'),('923,706.78',NULL,'2022-02-16'),('924,216.42',NULL,'2022-03-14'),('924,421.39',NULL,'2022-05-25'),('924,561.28',NULL,'2022-06-10'),('925,064.93',NULL,'2022-08-29'),('925,181.33',NULL,'2022-05-09'),('925,432.85',NULL,'2022-03-08'),('925,844.80',NULL,'2022-05-13'),('926,019.91',NULL,'2022-08-10'),('926,285.31',NULL,'2022-03-15'),('926,292.16',NULL,'2022-02-11'),('927,770.62',NULL,'2022-08-24'),('929,725.47','32,920.46','2022-12-16'),('929,755.99',NULL,'2022-03-09'),('929,757.82',NULL,'2022-02-10'),('930,051.82',NULL,'2022-03-11'),('930,600.24',NULL,'2022-08-11'),('931,182.83','33,715.37','2022-11-10'),('931,310.68',NULL,'2022-08-23'),('931,403.47',NULL,'2022-04-29'),('931,698.76',NULL,'2022-05-16'),('932,422.13',NULL,'2022-03-07'),('934,158.09',NULL,'2022-08-25'),('934,659.48',NULL,'2022-03-16'),('935,721.42',NULL,'2022-05-02'),('938,139.10',NULL,'2022-08-19'),('939,337.32','33,202.22','2022-12-15'),('939,547.28',NULL,'2022-05-26'),('939,821.43',NULL,'2022-03-10'),('939,977.88','33,476.46','2022-12-09'),('940,265.26',NULL,'2022-08-15'),('940,928.56',NULL,'2022-05-03'),('941,196.09','33,700.28','2022-11-21'),('941,252.41',NULL,'2022-06-09'),('941,565.96',NULL,'2022-05-17'),('941,997.75','33,553.83','2022-11-16'),('942,163.51',NULL,'2022-08-12'),('942,200.51','33,747.86','2022-11-11'),('942,747.01',NULL,'2022-04-27'),('943,282.30',NULL,'2022-08-17'),('944,492.71','33,546.32','2022-11-17'),('945,086.14',NULL,'2022-04-26'),('945,247.34','33,597.92','2022-12-07'),('945,515.63','33,745.69','2022-11-18'),('945,592.53',NULL,'2022-05-05'),('945,675.77','33,781.48','2022-12-08'),('945,880.62','33,536.70','2022-11-14'),('946,322.47',NULL,'2022-08-18'),('947,389.49',NULL,'2022-06-03'),('947,435.05',NULL,'2022-08-16'),('947,610.22',NULL,'2022-06-01'),('947,985.75',NULL,'2022-05-27'),('948,146.59',NULL,'2022-04-28'),('948,803.37','34,005.04','2022-12-12'),('948,809.22',NULL,'2022-05-31'),('948,816.03',NULL,'2022-05-06'),('950,057.51','33,596.34','2022-12-06'),('950,327.08',NULL,'2022-04-15'),('950,465.23',NULL,'2022-03-17'),('950,569.16',NULL,'2022-05-30'),('951,328.46',NULL,'2022-06-02'),('952,066.13','33,966.35','2022-12-14'),('952,250.20',NULL,'2022-06-06'),('952,305.30',NULL,'2022-06-08'),('952,915.53','34,108.64','2022-12-13'),('953,090.74','34,098.10','2022-11-22'),('953,262.02','33,849.46','2022-11-28'),('953,578.64','33,592.92','2022-11-15'),('954,602.92','34,194.06','2022-11-23'),('954,935.00',NULL,'2022-03-18'),('955,413.71',NULL,'2022-05-04'),('956,751.44','33,947.10','2022-12-05'),('957,096.63',NULL,'2022-06-07'),('957,224.74','34,194.06','2022-11-24'),('958,037.97','33,852.53','2022-11-29'),('960,439.69',NULL,'2022-04-25'),('960,884.69','34,347.03','2022-11-25'),('961,858.43',NULL,'2022-03-21'),('962,745.97',NULL,'2022-03-22'),('963,478.14',NULL,'2022-03-23'),('964,916.18','34,589.77','2022-11-30'),('965,861.25',NULL,'2022-03-24'),('966,388.96','34,395.01','2022-12-01'),('968,250.97','34,429.88','2022-12-02'),('971,349.02',NULL,'2022-04-22'),('972,254.85',NULL,'2022-03-31'),('972,650.52',NULL,'2022-04-18'),('972,846.56',NULL,'2022-04-01'),('973,322.92',NULL,'2022-04-15'),('974,331.59',NULL,'2022-04-04'),('974,633.14',NULL,'2022-03-25'),('974,729.66',NULL,'2022-03-29'),('976,413.92',NULL,'2022-04-19'),('982,636.35',NULL,'2022-03-30'),('985,492.48',NULL,'2022-04-21'),('988,949.58',NULL,'2022-04-20');
/*!40000 ALTER TABLE `stocktotals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `urlcountrycodes`
--

DROP TABLE IF EXISTS `urlcountrycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `urlcountrycodes` (
  `code` char(4) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `urlcountrycodes`
--

LOCK TABLES `urlcountrycodes` WRITE;
/*!40000 ALTER TABLE `urlcountrycodes` DISABLE KEYS */;
INSERT INTO `urlcountrycodes` VALUES ('ac','Ascension Island*'),('ad','Andorra'),('ae','United Arab Emirates'),('af','Afghanistan'),('ag','Antigua and Barbuda*'),('ai','Anguilla'),('al','Albania'),('am','Armenia*'),('an','Netherlands Antilles'),('ao','Angola'),('aq','Antarctica'),('ar','Argentina'),('as','American Samoa*'),('at','Austria*'),('au','Australia'),('aw','Aruba'),('ax','\Zland Islands'),('az','Azerbaijan'),('ba','Bosnia and Herzegovina'),('bb','Barbados'),('bd','Bangladesh'),('be','Belgium*'),('bf','Burkina Faso'),('bg','Bulgaria'),('bh','Bahrain'),('bi','Burundi*'),('bj','Benin'),('bl','Saint Barth\Zlemy'),('bm','Bermuda'),('bn','Brunei'),('bo','Bolivia*'),('br','Brazil*'),('bs','Bahamas*'),('bt','Bhutan'),('bv','Bouvet Island (not in use; no registrations)'),('bw','Botswana'),('by','Belarus'),('bz','Belize*'),('ca','Canada'),('cc','Cocos (Keeling) Islands*'),('cd','Democratic Republic of the Congo (formerly .zr - Zaire)*'),('cf','Central African Republic'),('cg','Republic of the Congo*'),('ch','Switzerland (Confoederatio Helvetica) *'),('','C\Zte d\'Ivoire (Ivory Coast)*'),('ck','Cook Islands*'),('cl','Chile'),('cm','Cameroon'),('co','Colombia'),('cr','Costa Rica'),('cu','Cuba'),('cv','Cape Verde'),('cx','Christmas Island*'),('cy','Cyprus'),('cz','Czech Republic'),('de','Germany'),('dj','Djibouti*'),('dk','Denmark*'),('dm','Dominica'),('do','Dominican Republic'),('dz','Algeria'),('ec','Ecuador*'),('ee','Estonia'),('eg','Egypt'),('eh','Western Sahara (not assigned; no DNS)'),('er','Eritrea'),('es','Spain*'),('et','Ethiopia'),('eu','European Union (code \"exceptionally reserved\" by ISO 3166-1)'),('fi','Finland'),('fj','Fiji*'),('fk','Falkland Islands'),('fm','Federated States of Micronesia*'),('fo','Faroe Islands'),('fr','France'),('ga','Gabon'),('gb','United Kingdom (Reserved domain by IANA; deprecated - see .uk)'),('gd','Grenada*'),('ge','Georgia'),('gf','French Guiana'),('gg','Guernsey'),('gh','Ghana'),('gi','Gibraltar'),('gl','Greenland*'),('gm','Gambia'),('gn','Guinea'),('gp','Guadeloupe'),('gq','Equatorial Guinea'),('gr','Greece*'),('gs','South Georgia and the South Sandwich Islands*'),('gt','Guatemala'),('gu','Guam'),('gw','Guinea-Bissau'),('gy','Guyana'),('hk','Hong Kong*'),('hm','Heard Island and McDonald Islands*'),('hn','Honduras*'),('hr','Croatia'),('ht','Haiti'),('hu','Hungary*'),('id','Indonesia'),('ie','Ireland'),('il','Israel*'),('im','Isle of Man*'),('in','India*'),('io','British Indian Ocean Territory*'),('iq','Iraq'),('ir','Iran*'),('is','Iceland*'),('it','Italy'),('je','Jersey'),('jm','Jamaica'),('jo','Jordan'),('jp','Japan'),('ke','Kenya'),('kg','Kyrgyzstan'),('kh','Cambodia'),('ki','Kiribati'),('km','Comoros'),('kn','Saint Kitts and Nevis'),('kp','North Korea'),('kr','South Korea'),('kw','Kuwait'),('ky','Cayman Islands'),('kz','Kazakhstan*'),('la','Laos*'),('lb','Lebanon'),('lc','Saint Lucia'),('li','Liechtenstein*'),('lk','Sri Lanka'),('lr','Liberia'),('ls','Lesotho*'),('lt','Lithuania'),('lu','Luxembourg'),('lv','Latvia*'),('ly','Libya*'),('ma','Morocco'),('mc','Monaco'),('md','Moldova*'),('me','Montenegro*'),('mg','Madagascar'),('mh','Marshall Islands'),('mk','Republic of Macedonia'),('ml','Mali'),('mm','Myanmar'),('mn','Mongolia*'),('mo','Macau'),('mp','Northern Mariana Islands*'),('mq','Martinique'),('mr','Mauritania'),('ms','Montserrat*'),('mt','Malta'),('mu','Mauritius*'),('mv','Maldives'),('mw','Malawi*'),('mx','Mexico*'),('my','Malaysia'),('mz','Mozambique'),('na','Namibia*'),('nc','New Caledonia'),('ne','Niger'),('nf','Norfolk Island*'),('ng','Nigeria'),('ni','Nicaragua'),('nl','Netherlands*'),('no','Norway'),('np','Nepal'),('nr','Nauru*'),('nu','Niue*'),('nz','New Zealand*'),('om','Oman'),('pa','Panama'),('pe','Peru'),('pf','French Polynesia'),('pg','Papua New Guinea'),('ph','Philippines*'),('pk','Pakistan*'),('pl','Poland*'),('pm','Saint Pierre and Miquelon'),('pn','Pitcairn Islands*'),('pr','Puerto Rico*'),('ps','Palestine*'),('pt','Portugal*'),('pw','Palau'),('py','Paraguay'),('qa','Qatar'),('re','R\Zunion'),('ro','Romania*'),('rs','Serbia*'),('ru','Russia*'),('rw','Rwanda'),('sa','Saudi Arabia'),('sb','Solomon Islands*'),('sc','Seychelles*'),('sd','Sudan'),('se','Sweden*'),('sg','Singapore'),('sh','Saint Helena*'),('si','Slovenia'),('sj','Svalbard and Jan Mayen islands (not in use; no registrations)'),('sk','Slovakia'),('sl','Sierra Leone'),('sm','San Marino*'),('sn','Senegal'),('so','Somalia'),('sr','Suriname*'),('st','S\Zo Tom\Z and Pr\Zncipe*'),('su','Soviet Union (deprecated; being phased out; code \"transitionally reserved\" by ISO 3166-1)'),('sv','El Salvador'),('sy','Syria*'),('sz','Swaziland*'),('tc','Turks and Caicos Islands*'),('td','Chad'),('tf','French Southern and Antarctic Lands'),('tg','Togo*'),('th','Thailand*'),('tj','Tajikistan*'),('tk','Tokelau*'),('tl','East Timor (formerly .tp)*'),('tm','Turkmenistan*'),('tn','Tunisia'),('to','Tonga*'),('tp','East Timor (deprecated - use .tl; code \"transitionally reserved\" by ISO 3166-1)'),('tr','Turkey'),('tt','Trinidad and Tobago*'),('tv','Tuvalu*'),('tw','Taiwan*'),('tz','Tanzania'),('ua','Ukraine'),('ug','Uganda*'),('uk','United Kingdom (code \"exceptionally reserved\" by ISO 3166-1) (see also .gb)'),('um','US Minor Outlying Islands (code terminated)'),('us','United States*'),('uy','Uruguay'),('uz','Uzbekistan'),('va','Vatican City'),('vc','Saint Vincent and the Grenadines*'),('ve','Venezuela'),('vg','British Virgin Islands*'),('vi','United States Virgin Islands'),('vn','Vietnam'),('vu','Vanuatu*'),('wf','Wallis and Futuna'),('ws','Samoa* (formerly Western Samoa)'),('ye','Yemen'),('yt','Mayotte'),('yu','Yugoslavia'),('za','South Africa*'),('zm','Zambia'),('zw','Zimbabwe');
/*!40000 ALTER TABLE `urlcountrycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verifyemail`
--

DROP TABLE IF EXISTS `verifyemail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verifyemail` (
  `listId` int NOT NULL AUTO_INCREMENT,
  `contactName` varchar(255) DEFAULT NULL,
  `contactEmail` varchar(255) NOT NULL,
  `teststatus` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`listId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verifyemail`
--

LOCK TABLES `verifyemail` WRITE;
/*!40000 ALTER TABLE `verifyemail` DISABLE KEYS */;
INSERT INTO `verifyemail` VALUES (1,'Barton Phillips','bartonphillips@gmail.com','ok'),(2,'Bonnie Burch','bonnieburch2015@gmail.com','ok'),(3,'Michel Friedmon','michrz76@gmail.com','ok'),(4,'Bob Who','bob@gmail.com','bad'),(5,'Barton Applitec','barton@applitec.com','cantsay'),(6,'Glen Humphrey','glenhumphrey@applitec.com','cantsay'),(7,'','','nottested');
/*!40000 ALTER TABLE `verifyemail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-18  2:03:30
