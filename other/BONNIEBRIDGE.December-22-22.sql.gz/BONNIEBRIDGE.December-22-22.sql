-- MySQL dump 10.13  Distrib 8.0.31, for Linux (x86_64)
--
-- Host: localhost    Database: bridge
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bridge`
--

DROP TABLE IF EXISTS `bridge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bridge` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(254) DEFAULT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fnamelname` (`fname`,`lname`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='BridgeNames';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bridge`
--

LOCK TABLES `bridge` WRITE;
/*!40000 ALTER TABLE `bridge` DISABLE KEYS */;
INSERT INTO `bridge` VALUES (2,'Bonnie Burch','Bonnie','Burch','2022-01-12 19:20:58','2022-01-12 19:20:58'),(3,'Anna Craft','Anna','Craft','2022-01-03 17:23:01','2022-01-03 17:23:01'),(4,'Bonnie Crosser','Bonnie','Crosser','2022-01-03 17:23:01','2022-01-03 17:23:01'),(6,'Bill Dorsey','Bill','Dorsey','2022-01-03 17:23:01','2022-01-03 17:23:01'),(7,'Gail Dupree','Gail','Dupree','2022-01-03 17:23:01','2022-01-03 17:23:01'),(8,'Pam Duling','Pam','Duling','2022-01-03 17:23:01','2022-01-03 17:23:01'),(9,'Dru Eckberg','Dru','Eckberg','2022-01-03 17:23:01','2022-01-03 17:23:01'),(10,'Joe Fogleman','Joe','Fogleman','2022-01-03 17:23:01','2022-01-03 17:23:01'),(11,'Howard Furnas','Howard','Furnas','2022-01-03 17:23:01','2022-01-03 17:23:01'),(12,'John Gignilliat','John','Gignilliat','2022-01-03 17:23:01','2022-01-03 17:23:01'),(13,'Heidi Gordon','Heidi','Gordon','2022-01-03 17:23:01','2022-01-03 17:23:01'),(15,'Olga Herman','Olga','Herman','2022-01-03 17:23:01','2022-01-03 17:23:01'),(17,'Marilyn Jacobs','Marilyn','Jacobs','2022-01-03 17:23:01','2022-01-03 17:23:01'),(18,'Paul Jambor','Paul','Jambor','2022-01-03 17:23:01','2022-01-03 17:23:01'),(19,'Ginny Jones','Ginny','Jones','2022-01-03 17:23:01','2022-01-03 17:23:01'),(20,'JoAnn Kerrick','JoAnn','Kerrick','2022-01-03 17:23:01','2022-01-03 17:23:01'),(21,'Ken Kirkman','Ken','Kirkman','2022-01-03 17:23:01','2022-01-03 17:23:01'),(22,'Sue Kleeman','Sue','Kleeman','2022-01-03 17:23:01','2022-01-03 17:23:01'),(23,'Richard Lambert','Richard','Lambert','2022-01-03 17:23:01','2022-01-03 17:23:01'),(25,'Tudi Moldestad','Tudi','Moldestad','2022-01-03 17:23:01','2022-01-03 17:23:01'),(26,'Fred Ohsol','Fred','Ohsol','2022-01-03 17:23:01','2022-01-03 17:23:01'),(27,'Mary Ann Ohsol','Mary Ann','Ohsol','2022-01-03 17:23:01','2022-01-03 17:23:01'),(28,'Peter Pagnutti','Peter','Pagnutti','2022-01-03 17:23:01','2022-01-03 17:23:01'),(29,'Mary Parker','Mary','Parker','2022-01-03 17:23:01','2022-01-03 17:23:01'),(30,'Carolyn Peterson','Carolyn','Peterson','2022-01-03 17:23:01','2022-01-03 17:23:01'),(32,'Barton Phillips','Barton','Phillips','2022-01-03 17:23:01','2022-01-03 17:23:01'),(33,'Mitchell Riley','Mitchell','Riley','2022-01-03 17:23:01','2022-01-03 17:23:01'),(34,'Jamie Schmidt','Jamie','Schmidt','2022-01-03 17:23:01','2022-01-03 17:23:01'),(35,'Lowell Stockdale','Lowell','Stockdale','2022-01-03 17:23:01','2022-01-03 17:23:01'),(36,'Sandra Tant','Sandra','Tant','2022-01-03 17:23:01','2022-01-03 17:23:01'),(37,'Chris Town','Chris','Town','2022-01-03 17:23:01','2022-01-03 17:23:01'),(38,'Bernie VanMiddlesworth','Bernie','VanMiddlesworth','2022-01-03 17:23:01','2022-01-03 17:23:01'),(39,'Sissy Weil','Sissy','Weil','2022-01-03 17:23:01','2022-01-03 17:23:01'),(40,'Joyce Waller','Joyce','Waller','2022-01-03 17:23:01','2022-01-03 17:23:01'),(41,'Bob Wengert','Bob','Wengert','2022-01-03 17:23:01','2022-01-03 17:23:01'),(42,'Gary White','Gary','White','2022-01-03 17:23:01','2022-01-03 17:23:01'),(43,'Ken Wilkins','Ken','Wilkins','2022-01-03 17:23:01','2022-01-03 17:23:01'),(44,'Dru Wilkins','Dru','Wilkins','2022-01-03 17:23:01','2022-01-03 17:23:01'),(45,'Ruth Willis','Ruth','Willis','2022-01-03 17:23:01','2022-01-03 17:23:01'),(46,'Earl Wingrove','Earl','Wingrove','2022-01-03 17:23:01','2022-01-03 17:23:01'),(47,'Judy Wooten','Judy','Wooten','2022-01-03 17:23:01','2022-01-03 17:23:01'),(48,'Sim Wooten','Sim','Wooten','2022-01-03 17:23:01','2022-10-20 21:20:12'),(49,'Eliza Worthington','Eliza','Worthington','2022-01-03 17:23:01','2022-01-03 17:23:01'),(50,'Mym Young','Mym','Young','2022-01-03 17:23:01','2022-01-03 17:23:01'),(53,'Valerie Cozart','Valerie','Cozart','2022-01-12 19:22:39','2022-01-12 19:22:39'),(54,'Barbara Macon','Barbara','Macon','2022-01-12 19:24:57','2022-01-17 20:55:50'),(55,'James Herren','James','Herren','2022-01-12 19:25:44','2022-01-12 19:25:44'),(56,'Mark Brennesholtz','Mark','Brennesholtz','2022-01-17 20:54:40','2022-01-17 20:54:40'),(57,'Susan Hopkins','Susan','Hopkins','2022-01-17 20:54:59','2022-01-17 20:54:59'),(59,'Mike Gooden','Mike','Gooden','2022-01-26 16:34:51','2022-01-26 16:34:51'),(60,'Sarah Kinsey','Sarah','Kinsey','2022-01-26 16:35:11','2022-01-26 16:35:11'),(61,'Joe Freiwald','Joe','Freiwald','2022-02-02 16:39:44','2022-02-02 16:39:44'),(62,'Susan Centner','Susan','Centner','2022-02-02 16:40:02','2022-02-02 16:40:02'),(63,'Susan Langdon','Susan','Langdon','2022-02-02 16:40:19','2022-02-02 16:40:19'),(65,'Beth Haigler','Beth','Haigler','2022-02-09 17:00:23','2022-02-09 17:00:23'),(66,'Cathy Howell','Cathy','Howell','2022-02-09 17:04:03','2022-02-09 17:04:03'),(67,'Mary Deckert','Mary','Deckert','2022-02-16 22:15:45','2022-02-16 22:15:45'),(68,'Suseen Banks','Suseen','Banks','2022-02-28 22:03:06','2022-02-28 22:03:06'),(69,'Ingrid Carmona','Ingrid','Carmona','2022-03-09 16:49:01','2022-03-09 16:49:01'),(70,'Jeannie Brennesholtz','Jeannie','Brennesholtz','2022-03-09 16:49:22','2022-03-09 16:49:22'),(72,'Sandy Craft','Sandy','Craft','2022-03-23 20:10:11','2022-03-23 20:10:11'),(73,'Judy Piper','Judy','Piper','2022-03-23 20:10:29','2022-03-23 20:10:29'),(74,'Jackie Nelson','Jackie','Nelson','2022-03-31 11:27:25','2022-03-31 11:27:25'),(75,'Pat Mayo','Pat','Mayo','2022-04-07 14:17:34','2022-04-07 14:17:34'),(76,'Anonymous Anon','Anonymous','Anon','2022-04-07 14:18:09','2022-04-07 14:18:09'),(77,'Thomas Connolly','Thomas','Connolly','2022-06-29 20:35:06','2022-06-29 20:35:06'),(78,'Mary Connolly','Mary','Connolly','2022-06-29 20:35:48','2022-06-29 20:35:48'),(79,'Sherry Foster','Sherry','Foster','2022-07-13 10:03:03','2022-07-13 10:03:03'),(80,'Judie Ware','Judie','Ware','2022-07-13 20:00:28','2022-07-13 20:00:28'),(81,'Pat Donaldson','Pat','Donaldson','2022-07-21 19:45:58','2022-07-21 19:45:58'),(82,'Fran Twisdale','Fran','Twisdale','2022-07-29 11:59:37','2022-07-29 11:59:37'),(84,'Maureen Mongan','Maureen','Mongan','2022-08-04 19:12:47','2022-08-04 19:12:47'),(85,'Al Takemoto','Al','Takemoto','2022-08-18 17:23:38','2022-08-18 17:23:38'),(86,'Joe Hatch','Joe','Hatch','2022-08-18 17:24:09','2022-08-18 17:24:09'),(87,'Andrea Scholl','Andrea','Scholl','2022-08-25 18:51:30','2022-08-25 18:51:30'),(88,'Debbie Morris','Debbie','Morris','2022-09-07 19:48:48','2022-09-07 19:48:48'),(89,'Francis Jilcott','Francis','Jilcott','2022-09-14 20:22:04','2022-09-14 20:22:04'),(90,'Bob Harper','Bob','Harper','2022-09-23 10:07:09','2022-09-23 10:07:09'),(91,'Bunny Macon','Bunny','Macon','2022-09-23 10:07:39','2022-09-23 10:07:39'),(92,'Buzz Snead','Buzz','Snead','2022-10-07 10:26:46','2022-10-07 10:26:46'),(93,'Fred Hausman','Fred','Hausman','2022-10-07 11:04:15','2022-10-26 18:46:30'),(94,'Kathleen Dillingham','Kathleen','Dillingham','2022-10-13 16:58:53','2022-10-13 16:58:53'),(95,'Martha Young','Martha','Young','2022-10-20 20:16:51','2022-10-20 20:16:51'),(96,'Ann Lockhart','Ann','Lockhart','2022-10-20 20:22:35','2022-10-20 20:22:35'),(97,'Bruce Mandela','Bruce','Mandela','2022-10-20 20:28:11','2022-10-20 20:28:11'),(99,'Emily Vaughn','Emily','Vaughn','2022-11-24 09:51:10','2022-11-24 09:51:10'),(100,'Jeannie Exum','Jeannie','Exum','2022-12-07 18:23:47','2022-12-07 18:23:47');
/*!40000 ALTER TABLE `bridge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `money`
--

DROP TABLE IF EXISTS `money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `money` (
  `fid` int NOT NULL,
  `date` date NOT NULL,
  `money` decimal(7,0) DEFAULT '0',
  `lasttime` datetime NOT NULL,
  UNIQUE KEY `fiddate` (`fid`,`date`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Donation';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `money`
--

LOCK TABLES `money` WRITE;
/*!40000 ALTER TABLE `money` DISABLE KEYS */;
/*!40000 ALTER TABLE `money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weeks`
--

DROP TABLE IF EXISTS `weeks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weeks` (
  `fid` int NOT NULL,
  `date` date NOT NULL,
  `lasttime` datetime NOT NULL,
  UNIQUE KEY `fiddate` (`fid`,`date`),
  KEY `fid` (`fid`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Attendance';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weeks`
--

LOCK TABLES `weeks` WRITE;
/*!40000 ALTER TABLE `weeks` DISABLE KEYS */;
/*!40000 ALTER TABLE `weeks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-22  2:03:31
