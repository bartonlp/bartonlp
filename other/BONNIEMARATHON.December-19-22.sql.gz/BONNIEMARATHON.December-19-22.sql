-- MySQL dump 10.13  Distrib 8.0.31, for Linux (x86_64)
--
-- Host: localhost    Database: marathon
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `scores`
--

DROP TABLE IF EXISTS `scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scores` (
  `fkteam` int NOT NULL,
  `month` varchar(20) NOT NULL,
  `moNo` int DEFAULT NULL,
  `score` int DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  PRIMARY KEY (`fkteam`,`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scores`
--

LOCK TABLES `scores` WRITE;
/*!40000 ALTER TABLE `scores` DISABLE KEYS */;
INSERT INTO `scores` VALUES (1,'April',9,0,NULL,NULL),(1,'December',3,0,NULL,NULL),(1,'February 1',6,0,NULL,NULL),(1,'February 2',7,0,NULL,NULL),(1,'January 1',4,0,NULL,NULL),(1,'January 2',5,0,NULL,NULL),(1,'March',8,0,NULL,NULL),(1,'May',10,0,NULL,NULL),(1,'November',2,0,NULL,NULL),(1,'October',1,780,'2022-10-15 10:14:07','2022-10-15 10:14:07'),(1,'September',0,3000,'2022-10-15 10:15:37','2022-10-15 10:15:37'),(2,'April',9,0,NULL,NULL),(2,'December',3,0,NULL,NULL),(2,'February 1',6,0,NULL,NULL),(2,'February 2',7,0,NULL,NULL),(2,'January 1',4,0,NULL,NULL),(2,'January 2',5,0,NULL,NULL),(2,'March',8,0,NULL,NULL),(2,'May',10,0,NULL,NULL),(2,'November',2,0,NULL,NULL),(2,'October',1,1420,'2022-10-16 17:12:59','2022-10-16 17:12:59'),(2,'September',0,2230,'2022-10-08 10:28:44','2022-10-08 10:28:44'),(3,'April',9,0,NULL,NULL),(3,'December',3,0,NULL,NULL),(3,'February 1',6,0,NULL,NULL),(3,'February 2',7,0,NULL,NULL),(3,'January 1',4,0,NULL,NULL),(3,'January 2',5,0,NULL,NULL),(3,'March',8,0,NULL,NULL),(3,'May',10,0,NULL,NULL),(3,'November',2,0,NULL,NULL),(3,'October',1,2710,'2022-10-16 17:12:59','2022-10-16 17:12:59'),(3,'September',0,2550,'2022-10-10 17:04:58','2022-10-10 17:04:58'),(4,'April',9,0,NULL,NULL),(4,'December',3,0,NULL,NULL),(4,'February 1',6,0,NULL,NULL),(4,'February 2',7,0,NULL,NULL),(4,'January 1',4,0,NULL,NULL),(4,'January 2',5,0,NULL,NULL),(4,'March',8,0,NULL,NULL),(4,'May',10,0,NULL,NULL),(4,'November',2,1570,'2022-11-19 12:10:04','2022-11-19 12:10:04'),(4,'October',1,1500,'2022-10-24 16:47:32','2022-10-24 16:47:32'),(4,'September',0,2200,'2022-10-10 17:04:58','2022-10-10 17:04:58'),(5,'April',9,0,NULL,NULL),(5,'December',3,0,NULL,NULL),(5,'February 1',6,0,NULL,NULL),(5,'February 2',7,0,NULL,NULL),(5,'January 1',4,0,NULL,NULL),(5,'January 2',5,0,NULL,NULL),(5,'March',8,0,NULL,NULL),(5,'May',10,0,NULL,NULL),(5,'November',2,0,NULL,NULL),(5,'October',1,1480,'2022-10-24 16:47:32','2022-10-24 16:47:32'),(5,'September',0,1940,'2022-10-08 10:28:44','2022-10-08 10:28:44'),(6,'April',9,0,NULL,NULL),(6,'December',3,0,NULL,NULL),(6,'February 1',6,0,NULL,NULL),(6,'February 2',7,0,NULL,NULL),(6,'January 1',4,0,NULL,NULL),(6,'January 2',5,0,NULL,NULL),(6,'March',8,0,NULL,NULL),(6,'May',10,0,NULL,NULL),(6,'November',2,1170,'2022-11-02 16:58:14','2022-11-02 16:58:14'),(6,'October',1,0,NULL,NULL),(6,'September',0,2410,'2022-10-08 10:28:44','2022-10-08 10:28:44'),(7,'April',9,0,NULL,NULL),(7,'December',3,0,NULL,NULL),(7,'February 1',6,0,NULL,NULL),(7,'February 2',7,0,NULL,NULL),(7,'January 1',4,0,NULL,NULL),(7,'January 2',5,0,NULL,NULL),(7,'March',8,0,NULL,NULL),(7,'May',10,0,NULL,NULL),(7,'November',2,0,NULL,NULL),(7,'October',1,0,NULL,NULL),(7,'September',0,840,'2022-10-08 10:28:44','2022-10-08 10:28:44'),(8,'April',9,0,NULL,NULL),(8,'December',3,0,NULL,NULL),(8,'February 1',6,0,NULL,NULL),(8,'February 2',7,0,NULL,NULL),(8,'January 1',4,0,NULL,NULL),(8,'January 2',5,0,NULL,NULL),(8,'March',8,0,NULL,NULL),(8,'May',10,0,NULL,NULL),(8,'November',2,3390,'2022-10-24 16:48:30','2022-10-24 16:48:30'),(8,'October',1,2940,'2022-10-17 09:11:39','2022-10-17 09:11:39'),(8,'September',0,3410,'2022-10-08 10:28:44','2022-10-08 10:28:44'),(9,'April',9,0,NULL,NULL),(9,'December',3,0,NULL,NULL),(9,'February 1',6,0,NULL,NULL),(9,'February 2',7,0,NULL,NULL),(9,'January 1',4,0,NULL,NULL),(9,'January 2',5,0,NULL,NULL),(9,'March',8,0,NULL,NULL),(9,'May',10,0,NULL,NULL),(9,'November',2,0,NULL,NULL),(9,'October',1,3090,'2022-10-17 09:11:39','2022-10-17 09:11:39'),(9,'September',0,3880,'2022-10-08 10:28:44','2022-10-08 10:28:44'),(10,'April',9,0,NULL,NULL),(10,'December',3,0,NULL,NULL),(10,'February 1',6,0,NULL,NULL),(10,'February 2',7,0,NULL,NULL),(10,'January 1',4,0,NULL,NULL),(10,'January 2',5,0,NULL,NULL),(10,'March',8,0,NULL,NULL),(10,'May',10,0,NULL,NULL),(10,'November',2,1730,'2022-11-19 12:10:04','2022-11-19 12:10:04'),(10,'October',1,640,'2022-10-16 17:12:59','2022-10-16 17:12:59'),(10,'September',0,750,'2022-10-08 10:28:44','2022-10-08 10:28:44'),(11,'April',9,0,NULL,NULL),(11,'December',3,0,NULL,NULL),(11,'February 1',6,0,NULL,NULL),(11,'February 2',7,0,NULL,NULL),(11,'January 1',4,0,NULL,NULL),(11,'January 2',5,0,NULL,NULL),(11,'March',8,0,NULL,NULL),(11,'May',10,0,NULL,NULL),(11,'November',2,2170,'2022-10-24 17:16:46','2022-10-24 17:16:46'),(11,'October',1,4600,'2022-10-16 17:12:59','2022-10-16 17:12:59'),(11,'September',0,1530,'2022-10-08 10:30:00','2022-10-08 10:30:00'),(12,'April',9,0,NULL,NULL),(12,'December',3,0,NULL,NULL),(12,'February 1',6,0,NULL,NULL),(12,'February 2',7,0,NULL,NULL),(12,'January 1',4,0,NULL,NULL),(12,'January 2',5,0,NULL,NULL),(12,'March',8,0,NULL,NULL),(12,'May',10,0,NULL,NULL),(12,'November',2,2220,'2022-11-02 16:58:14','2022-11-02 16:58:14'),(12,'October',1,3930,'2022-10-15 10:14:07','2022-10-15 10:14:07'),(12,'September',0,1890,'2022-10-15 10:15:37','2022-10-15 10:15:37');
/*!40000 ALTER TABLE `scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teams` (
  `team` int NOT NULL,
  `name1` varchar(100) NOT NULL,
  `name2` varchar(100) NOT NULL,
  `email1` varchar(100) NOT NULL,
  `email2` varchar(100) NOT NULL,
  `phone1` varchar(20) DEFAULT NULL,
  `phone2` varchar(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  `lasttime` datetime NOT NULL,
  PRIMARY KEY (`team`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (1,'Cheryl Ashe','West Munz','cheryllee@suddenlink.net','nflcash500@yahoo.com','(252) 636-0966','(949) 307-4532','2022-08-22 17:21:08','2022-08-27 13:15:01'),(2,'Bill Gehlert','Barbara Gehlert','barcarwil@suddenlink.net','','(252) 636-3105','','2022-08-22 17:21:08','2022-08-27 13:15:01'),(3,'Ceil Wasserman','Jerry Kopec','crwasserman@yahoo.com','kopecjerome7@gmail.com','(252) 672-1755','(252) 876-8040','2022-08-22 17:21:08','2022-08-27 13:15:01'),(4,'Henry Gerock','Pat Hawkins','docgerock@yahoo.com','patack37@gmail.com','(910) 340-8819','(252) 633-6888','2022-08-22 17:21:08','2022-08-27 14:27:15'),(5,'Gary White','Vickie White','1941garywh@gmail.com','','(252) 349-7862','(252) 349-1962','2022-08-22 17:21:08','2022-08-27 13:15:01'),(6,'Mary Ann Ohsol','Fred Ohsol','maohsol@gmail.com','fohsol@gmail.com','(252) 876-5410','(252) 876-5480','2022-08-22 17:21:08','2022-08-27 13:15:02'),(7,'Rebecca Liberty','Mike Liberty','Rebeccaliberty@embarqmail.com','Michaelliberty@embarqmail.com','(252) 670-7601','(252)670-7602','2022-08-22 17:21:08','2022-12-13 10:43:12'),(8,'Joyce Waller','Peter Pagnutti','wallwalla1940@gmail.com','hp1958@embarqmail.com','(252) 670-6636','(252) 349-2927','2022-08-22 17:21:08','2022-08-27 13:15:02'),(9,'Bernie VanMiddlesworth','Judy Wooten','bernie@vanmiddlesworth.org','','(765) 977-6363','(252) 631-2124','2022-08-22 17:21:08','2022-08-27 13:15:02'),(10,'Judy Zellers','Phil Zellers','zellph@hotmail.com','','(252) 514-2303','','2022-08-22 17:21:08','2022-08-27 13:15:02'),(11,'Bonnie Burch','Barton Phillips','bonnieburch2015@gmail.com','bartonphillips@gmail.com','(817) 528-2036','(252) 670-6424','2022-08-22 17:21:08','2022-08-27 13:15:02'),(12,'Bob Wengert','Pat Mayo','bobwengert5@gmail.com','pmayo2@yahoo.com','(252) 649-1333','(252) 626-8393','2022-08-22 17:21:08','2022-08-27 13:15:02');
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-19  2:03:29
